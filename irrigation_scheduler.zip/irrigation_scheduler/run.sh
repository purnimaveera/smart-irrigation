#!/bin/sh
# Build and start the Smart Irrigation Scheduler (Linux / macOS). Opens your browser.
cd "$(dirname "$0")" || exit 1
make irrigation_server && ./irrigation_server "$@"
