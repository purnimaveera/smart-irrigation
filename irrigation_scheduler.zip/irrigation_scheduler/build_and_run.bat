@echo off
cd /d "%~dp0"
echo Building...
g++ -std=c++17 -O2 -static server.cpp -o irrigation_server.exe -lws2_32
if errorlevel 1 (
  echo BUILD FAILED - is g++ ^(MinGW^) installed and in PATH?
  pause
  exit /b 1
)
echo Build OK. Starting server - your browser will open automatically...
irrigation_server.exe
pause
