# Smart Irrigation Scheduler (C++)

Schedules irrigation for farm zones using soil moisture, rain forecast and crop needs, to save water.

| Requirement | Where |
|---|---|
| Greedy: driest zone first | `IrrigationScheduler::computeSchedule` |
| Min-Heap priority list | `MinHeap.h` (used by the scheduler **and** Dijkstra) |
| Graph of pipes + shortest path | `Graph.h` (Dijkstra) |

## Run (one command)
- **Windows:** double-click `build_and_run.bat`
- **Linux / macOS:** `./run.sh`

Needs only `g++` (C++17). No libraries. The browser opens at **http://localhost:8080**
(if 8080 is busy it tries 8081, 8082 ...). Options: `./irrigation_server 9090 --no-browser`

## Project layout
```
server.cpp            routes + sample farm data
HttpServer.h          tiny HTTP server (no dependencies)
Graph.h               pipe network + Dijkstra
MinHeap.h             generic binary min-heap
IrrigationScheduler.h greedy scheduling logic
Json.h                JSON output
Zone.h                zone data
public/index.html     frontend (edit and just refresh the browser - no rebuild)
```

## Using the UI
- **Generate schedule** - see order, litres, pump time, pipe losses.
- **Pipe network** - drag nodes, click an outlet/row to see its animated route; blue lines are the full shortest-path tree.
- **Min-Heap** - tree + array view of the priority list.
- **Edit pipe network** - add nodes/pipes or remove a pipe to watch Dijkstra re-route.

## API
`GET /api/zones` `GET /api/network` `GET /api/schedule?budget=6000`
`POST /api/update|add|delete|reset|node|pipe|unpipe|move`
